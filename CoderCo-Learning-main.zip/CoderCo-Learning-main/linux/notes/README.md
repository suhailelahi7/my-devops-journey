# Linux notes
