#!/bin/bash

for variable in sequence 
do
    # Code block to be excuted 
done

Example:

#!/bin/bash

for (( i=1; i<5; i++ ))
do
    echo "Number: $i"
done