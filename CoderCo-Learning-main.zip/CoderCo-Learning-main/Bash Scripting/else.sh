#!/bin/bash

if condition 
then 
    # Code block if condition is true 
else 
    # Code block if condition is false 
fi    