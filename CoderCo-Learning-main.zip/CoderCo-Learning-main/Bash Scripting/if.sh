#!/bin/bash

age=25

if [ $age -gt 18]
then
    echo "You are an adult!"
fi